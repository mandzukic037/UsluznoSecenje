# Upgrade Plan: usluznosecenje (20260611174814)

- **Generated**: 2026-06-11 17:48 UTC
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21.0.11: `C:\Program Files\Eclipse Adoptium\jdk-21.0.11.10-hotspot\bin` (current project JDK, used by baseline)
- JDK 25.0.3: `C:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot\bin` (required by upgrade and final validation)

**Build Tools**
- Maven Wrapper 3.9.16: `mvnw.cmd` / `.mvn/wrapper/maven-wrapper.properties` (used for all build and test steps)
- System Maven 3.x: `D:\Maven\bin` (available, but wrapper is preferred)

## Guidelines

- Upgrade the runtime target to the latest LTS, Java 25.
- Keep the change set minimal and focused on runtime compatibility.
- Version control is not available in this workspace, so changes will remain uncommitted.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260611174814
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS runtime |
| Spring Boot starter parent | 4.1.0 | 4.1.0 | Compatible with Java 25; no framework upgrade required |
| Maven Wrapper | 3.9.16 | 3.9.0 | Compatible with Java 25; no build-tool upgrade required |

## Derived Upgrades

- None required beyond the Java target bump. The existing Maven wrapper already satisfies Java 25 compatibility guidance, and no Kotlin or Gradle tooling is present.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version | 21 | upgrade | 25 | Align the compiler and runtime target with Java 25 |

### Source Code Changes

- None identified. The application is a minimal Spring Boot launcher and context-load test with no Java-version-sensitive APIs.

### Configuration Changes

- None identified.

### CI/CD Changes

- None identified.

### Risks & Warnings

- **Runtime behavior changes in Java 25**: The app is small and compiles cleanly, but new JDK defaults can still affect startup or tests at runtime. **Mitigation**: run the full test suite on JDK 25 in final validation.
- **No version control available**: Changes cannot be committed in this workspace. **Mitigation**: keep `progress.md` and `summary.md` as the execution record.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm the required JDKs and build tool are present before touching project files.
  - **Changes to Make**: None; verify installed JDK 21 and JDK 25, plus the Maven wrapper.
  - **Verification**: `#appmod-list-jdks` and `#appmod-list-mavens`, expected result: JDK 21 and 25 available, wrapper-compatible Maven available.

- Step 2: Setup Baseline
  - **Rationale**: Establish the current pass/fail state on the existing Java 21 runtime before upgrading.
  - **Changes to Make**: None; run baseline compile and tests on JDK 21.
  - **Verification**: `./mvnw.cmd clean compile test-compile -q && ./mvnw.cmd clean test -q` on JDK 21. Expected result: baseline build and test suite complete successfully.

- Step 3: Upgrade Java Target to 25
  - **Rationale**: This is the only functional project change required to move the runtime target to the latest LTS.
  - **Changes to Make**: Apply the dependency change in `pom.xml` for `java.version` from 21 to 25.
  - **Verification**: `./mvnw.cmd clean test-compile -q` on JDK 25. Expected result: production code and tests compile successfully.

- Step 4: CVE Validation & Dependency Re-scan
  - **Rationale**: Required by the upgrade workflow to confirm the direct dependency set remains secure after the Java bump.
  - **Changes to Make**: Only if the scan reports actionable CVEs; otherwise leave the build unchanged.
  - **Verification**: Extract direct dependencies and scan them with the CVE tool, then re-run `./mvnw.cmd clean test-compile -q` if any dependency version changes were needed.

- Step 5: Final Validation
  - **Rationale**: Prove the upgraded project builds and tests cleanly on the target JDK.
  - **Changes to Make**: None beyond any CVE-driven dependency adjustments from Step 4.
  - **Verification**: `./mvnw.cmd clean test -q` on JDK 25. Expected result: full test suite passes on the final target runtime.
